function convertDate() {
    return function(value) {
        //return 'Hellp'
        if (value === ""){
            return ""
        } else {
            return new Date(value);
        }
    };
}

angular
    .module('NotesApp')
    .filter('newDate', convertDate);