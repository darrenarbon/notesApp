app.service('dbCall', function ($http, $q) {

    //old one
    //var myDB = window.sqlitePlugin.openDatabase({name: "mySQLite.db", location: 'default'});


    var myDB = openDatabase("Memos.db", "default", "Desc", "1000");

    this.getData = function (query, params = []) {
        console.log("Transaction Query : " + query);
        return $q(function (resolve, reject) {
            myDB.transaction(function (transaction) {
                transaction.executeSql(query, params, function (transaction, result) {
                    //console.log(result.rows);
                    var resultsArray = []
                    for (var i = 0; i < result.rows.length; i++) {
                        resultsArray.push(result.rows[i])
                    }
                    resolve(resultsArray); // here the returned Promise is resolved
                }, nullHandler, errorHandler);
            });
        });
    }

    this.modifyData = function (query, params = []) {
        console.log("Transaction Query : " + query);
        return $q(function (resolve, reject) {
            myDB.transaction(function (transaction) {
                transaction.executeSql(query, params, function (transaction, result) {
                    resolve(result); // here the returned Promise is resolved
                }, nullHandler, errorHandler);
            });
        });
    }

    function nullHandler(error) {
        console.log(error)
    }

    function errorHandler(error) {
        console.log("error handler")
    }

    this.setupData = function() {
        //myDB.transaction(function(transaction) {
        //    transaction.executeSql("DELETE FROM notes", [],
        //        function(tx, result) {
        //            console.log("Table created successfully");
        //        },
        //        function(error) {
        //            console.log("Error occurred while creating the table.");
        //        });
        //});

        myDB.transaction(function(transaction) {
            transaction.executeSql("CREATE TABLE IF NOT EXISTS notes (note_id integer primary key, title text, notes text, date_added text default current_timestamp, colour text, date_due text, complete integer default(0))", [],
                function(tx, result) {
                    //console.log("Table created successfully");
                },
                function(error) {
                    //console.log("Error occurred while creating the table.");
                });
        });

        //var arrData = [["Learn AngularJS", "Find a course and learn it",'red'],
        //    ["Cook Dinner", "Recipe from good food guide",'blue'],
        //    ["Vimto on offer at tesco", "25% off with code: VIM25",'orange'],
        //    ["Loft Boarding", "B&Q have deals at the moment",'blue']]
        //
        //
        //arrData.forEach(function(data) {
        //    myDB.transaction(function(transaction) {
        //        //console.log(data)
        //        var executeQuery = "INSERT INTO notes (title, notes, colour) VALUES (?,?,?)";
        //        transaction.executeSql(executeQuery, data
        //            , function(tx, result) {
        //                console.log('Inserted');
        //            },
        //            function(error){
        //                console.log('Error occurred');
        //            });
        //    });
        //})
    }

});