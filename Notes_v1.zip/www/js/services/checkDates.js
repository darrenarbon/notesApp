app.service('checkDates', function () {
    this.checkOverDue = function(date) {
        var now = new Date()
        date = new Date(date)
        if (now.getFullYear() === date.getFullYear() && now.getMonth() === date.getMonth() && now.getDate() === date.getDate()) {
            //same day
            return "noteDueToday"
        } else if (Date.parse(now) > Date.parse(date)){
            return "noteOverdue"
        }
    }


});