var app = angular.module('NotesApp', ['ngRoute']);

app.config(function ($routeProvider) {
    $routeProvider
        .when('/notes', {
            controller: 'ListController',
            templateUrl: 'views/list.html'
        })
        .when('/notes/:id', {
            controller: 'MemoController',
            templateUrl: 'views/ind_memo.html'
        })
        .when('/notes/:id/edit', {
            controller: 'NewNoteController',
            templateUrl: 'views/newnote.html'
        })
        .when('/newnote', {
            controller: 'NewNoteController',
            templateUrl: 'views/newnote.html'
        })
        .otherwise({
            redirectTo: '/notes'
        });

});