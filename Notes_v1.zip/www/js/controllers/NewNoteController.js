app.controller('NewNoteController', function($scope,dbCall,$location, $routeParams) {
    $scope.note = {
        title: "",
        notes: "",
        date_due: "",
        colour: ""
    }



    if($routeParams.id) {
        dbCall.getData("Select * FROM notes where note_id=?", [$routeParams.id]).then(function(result) {
            $scope.note = result[0]
            $scope.buttonLabel = "Update Note"
            $scope.note.date_due = new Date($scope.note.date_due = new Date())
        })
    } else {
        $scope.buttonLabel = "Add Note"
    }

    $scope.submitNote = function(id) {
        if ($scope.note.date_due === undefined) $scope.note.date_due = "";
        if (id){
            //update
            dbCall.modifyData("update notes set title = ?, notes = ?, date_due = ?, colour =? where note_id=?", [$scope.note.title, $scope.note.notes, $scope.note.date_due, $scope.note.colour, id]).then(function(result) {
                $location.path("/notes/" + $routeParams.id)
            })
        } else {
            dbCall.modifyData("insert into notes (title, notes, date_due, colour) values (?,?,?,?)", [$scope.note.title, $scope.note.notes, $scope.note.date_due, $scope.note.colour]).then(function(result) {
                $location.path("/notes")
            })
        }
    }
});