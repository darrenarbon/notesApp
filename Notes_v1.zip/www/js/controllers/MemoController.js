app.controller('MemoController', function($scope,dbCall, $routeParams, checkDates, $location) {
    $scope.note = []

    dbCall.getData("Select * FROM notes where note_id=?", [$routeParams.id]).then(function(result) {
        $scope.note = result[0]
        $scope.note.class = checkDates.checkOverDue($scope.note.date_due)
    })

    $scope.deleteItem = function(id) {
        console.log("Delete: " + id)
        dbCall.modifyData("update notes set complete=1 where note_id=?", [id]).then(function(result) {
            $location.path("/notes")
        })
    }

    $scope.editItem = function(id) {
        console.log("Edit: " + id)
        $location.path("/notes/" + $routeParams.id +"/edit")
    }


});