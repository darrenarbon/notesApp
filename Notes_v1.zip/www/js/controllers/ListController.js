app.controller('ListController', function($scope, dbCall, $q, $location, checkDates) {
    $scope.notes = []

    dbCall.setupData()

    dbCall.getData("Select * FROM notes where complete=0").then(function(result) {
        $scope.notes = result
        $scope.notes.forEach(function(note){
            note.class = checkDates.checkOverDue(note.date_due)
        })

    })

    $scope.deleteItem = function(id) {
        console.log("hello: " + id)
        dbCall.modifyData("update notes set complete=1 where note_id=?", [id]).then(function(result) {
            $location.path("/notes")
        })
    }


});